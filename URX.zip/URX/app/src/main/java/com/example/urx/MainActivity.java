package com.example.urx;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText loguser, logpass;
    Button logbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        loguser=findViewById(R.id.lmail);
        logpass=findViewById(R.id.lpass);
        logbutton=findViewById(R.id.lbutton);

    }

    public void click(View view) {
        String s1=loguser.getText().toString();
        String s2=logpass.getText().toString();

        if(s1.equals("fayaz")&&s2.equals("12345"))
        {
            Toast.makeText(this,"successfully login",
                    Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(this,"failed",
                    Toast.LENGTH_SHORT).show();
        }
    }
}